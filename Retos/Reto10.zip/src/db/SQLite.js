import * as SQLite from 'expo-sqlite';

export default SQLite.openDatabase('MyDB');
