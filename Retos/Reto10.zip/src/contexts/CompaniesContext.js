import React, { useState, useEffect } from 'react';
import * as SQLite from 'expo-sqlite';
import db from '../db/SQLite';
import 'react-native-get-random-values';
import { v4 as uuid } from 'uuid';

const CompaniesContext = React.createContext({
  selectedCompany: {},
  companiesList: [],
});

export const CompaniesProvider = ({ children }) => {
  const [selectedCompany, setSelectedCompany] = useState({});
  const [companiesList, setCompaniesList] = useState([]);

  const selectCompany = (value) => {
    setSelectedCompany(value);
  };

  const createCompany = ({
    name,
    url,
    number,
    email,
    products,
    clasification,
  }) => {
    db.transaction((tx) => {
      tx.executeSql(
        'insert into Empresas (id, name, url, phoneNumber, email, products, clasification) values (?,?,?,?,?,?,?)',
        [uuid(), name, url, number, email, products, clasification],
        null,
        (a, error) => {
          console.log(error);
        }
      );
    });
  };

  const getCompanies = ({ name, clasification }) => {
    db.transaction((tx) => {
      tx.executeSql(
        `select * from Empresas`,
        [],
        (a, b) => {
          let result = b.rows._array;
          //console.log('list', b.rows._array);
          if (name) {
            result = result.filter(
              (item) => item.name.toLowerCase().search(name.toLowerCase()) != -1
            );
          }
          if (clasification) {
            result = result.filter(
              (item) => item.clasification.search(clasification) != -1
            );
          }
          setCompaniesList(result);
        },
        (a, b) => {
          console.log(b);
        }
      );
    });
  };

  const deleteCompany = (value) => {
    db.transaction((tx) => {
      tx.executeSql(
        'delete from Empresas where id=?',
        [value],
        null,
        (a, b) => {
          console.log(b);
        }
      );
    });
  };

  const updateCompany = ({
    id,
    name,
    url,
    number,
    email,
    products,
    clasification,
  }) => {
    db.transaction((tx) => {
      tx.executeSql(
        'update Empresas set name=?, url=?, phoneNumber=?, email=?, products=?, clasification=? where id=?',
        [name, url, number, email, products, clasification, id],
        null,
        (a, b) => {
          console.log(b);
        }
      );
    });
  };

  return (
    <CompaniesContext.Provider
      value={{
        selectedCompany,
        selectCompany,
        companiesList,
        setCompaniesList,
        createCompany,
        getCompanies,
        deleteCompany,
        updateCompany,
      }}
    >
      {children}
    </CompaniesContext.Provider>
  );
};

export default CompaniesContext;
