import React, { useState, useContext, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from 'react-native';
import { Portal, Dialog, Button as Bt } from 'react-native-paper';
import Constants from 'expo-constants';
import axios from 'axios';
import { Picker } from '@react-native-picker/picker';

const Main = ({ navigation }) => {
  const [data, setData] = useState([]);
  const [departamento, setDepartamento] = useState('ANTIOQUIA');
  const [loading, setLoading] = useState(false);

  const depart = [
    'AMAZONAS',
    'ANTIOQUIA',
    'ARAUCA',
    'ATLÁNTICO',
    'BOLIVAR',
    'BOLÍVAR',
    'BOYACÁ',
    'CALDAS',
    'CAQUETÁ',
    'CASANARE',
    'CAUCA',
    'CESAR',
    'CHOCÓ',
    'CÓRDOBA',
    'CUNDINAMARCA',
    'GUAINÍA',
    'GUAVIARE',
    'HUILA',
    'LA GUAJIRA',
    'MAGDALENA',
    'META',
    'NARIÑO',
    'NORTE DE SANTANDER',
    'PUTUMAYO',
    'QUINDÍO',
    'RISARALDA',
    'SAN ANDRÉS Y PROVIDENCIA',
    'SANTANDER',
    'SUCRE',
    'TOLIMA',
    'VALLE DEL CAUCA',
    'VAUPÉS',
    'VICHADA',
  ];

  const handleAddCompany = () => {
    navigation.push('AddCompany');
  };

  const handleSeeCompanies = () => {
    navigation.push('SeeCompanies');
  };
  const hideNameDialog = () => {
    setNameVisible(false);
  };

  useEffect(() => {
    setLoading(true);
    const getBussiness = async () => {
      const response = await axios
        .get('https://www.datos.gov.co/resource/rggv-qcwf.json', {
          params: {
            $$app_token: 'lm1bszJBzEfkJHWm4omgcdj3W',
            departamento: departamento,
          },
        })
        .catch((err) => {
          console.log('error', err);
        });
      setData(response.data);
      setLoading(false);
    };
    getBussiness();
  }, [departamento]);

  const renderBusiness = () => {
    return data.map((item, index) => {
      return (
        <TouchableOpacity key={index + item.raz_n_social} style={styles.card}>
          <Text style={styles.name}>{item.raz_n_social}</Text>
          <Text style={styles.info}>{item.producto_principal}</Text>
          <Text style={styles.info}>{item.nombre_representante}</Text>
          <Text style={styles.info}>{item.correo_electronico}</Text>
          <Text
            style={styles.info}
          >{`${item.municipio} - ${item.departamento}`}</Text>
        </TouchableOpacity>
      );
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.settings}>Green Business</Text>
      <Picker
        selectedValue={departamento}
        style={{ height: 50 }}
        onValueChange={(itemValue) => {
          setDepartamento(itemValue);
        }}
      >
        {depart.map((item) => {
          return <Picker.Item key={item} label={item} value={item} />;
        })}
      </Picker>
      <ScrollView>
        {loading ? (
          <View>
            <Text>Loading</Text>
          </View>
        ) : data.length != 0 ? (
          renderBusiness()
        ) : null}
      </ScrollView>
    </View>
  );
};
export default Main;

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    height: '100%',
    paddingHorizontal: '5%',
  },
  settings: { fontSize: 30, paddingVertical: '5%' },
  card: {
    borderColor: 'grey',
    borderWidth: 1,
    borderRadius: 10,
    marginVertical: 10,
  },
  name: {
    fontSize: 18,
    padding: '3%',
    fontWeight: 'bold',
    borderBottomWidth: 1,
    borderColor: 'lightgrey',
  },
  info: {
    fontSize: 16,
    padding: '2%',
    fontWeight: 'bold',
  },
});
