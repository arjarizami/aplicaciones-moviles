import React from 'react';
import {
  createNavigationContainer,
  NavigationContainer,
} from '@react-navigation/native';

import { createStackNavigator } from '@react-navigation/stack';
import { Provider as PaperProvider } from 'react-native-paper';
import { CompaniesProvider } from './src/contexts/CompaniesContext.js';

import Main from './src/screens/Main';

const Stack = createStackNavigator();

console.ignoredYellowBox = ['Setting a timer'];

export default function App() {
  return (
    <PaperProvider>
      <CompaniesProvider>
        <NavigationContainer>
          <Stack.Navigator
            inittialRoute='Main'
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen name='Main' component={Main} />
          </Stack.Navigator>
        </NavigationContainer>
      </CompaniesProvider>
    </PaperProvider>
  );
}
