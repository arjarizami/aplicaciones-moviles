import React, { useState, useContext, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { Portal, Dialog, Button as Bt } from 'react-native-paper';
import CompaniesContext from '../contexts/CompaniesContext.js';
import Constants from 'expo-constants';
import { ScrollView } from 'react-native-gesture-handler';
import { Picker } from '@react-native-picker/picker';

const CompaniesList = ({ navigation }) => {
  const [deleteId, setDeleteId] = useState('');
  const [deleteVisible, setDeleteVisible] = useState(false);

  const [filterVisible, setFilterVisible] = useState(false);
  const [filter, setFilter] = useState({ name: '', clasification: '' });

  const {
    getCompanies,
    companiesList,
    deleteCompany,
    selectCompany,
  } = useContext(CompaniesContext);

  useEffect(() => {
    getCompanies(filter);
  }, []);

  const handleEdit = (company) => {
    selectCompany(company);
    navigation.push('EditCompany');
  };

  const handleDelete = () => {
    deleteCompany(deleteId);
    getCompanies(filter);
    hideDeleteDialog();
  };

  const showDeleteDialog = () => {
    setDeleteVisible(true);
  };
  const hideDeleteDialog = () => {
    setDeleteVisible(false);
  };

  const showFilterDialog = () => {
    setFilterVisible(true);
  };
  const hideFilterDialog = () => {
    setFilterVisible(false);
  };

  const handleFilterChange = (value, key) => {
    setFilter({ ...filter, [key]: value });
    console.log(filter);
  };

  const handleFilter = (value, key) => {
    getCompanies(filter);
    hideFilterDialog();
    console.log(filter);
  };

  const renderCompanies = () => {
    return companiesList.map((item) => {
      return (
        <View style={styles.option} key={item.id}>
          <Text style={styles.optionText}>{item.name}</Text>
          <Text style={styles.details}>{item.url}</Text>
          <Text style={styles.details}>{item.email}</Text>
          <Text style={styles.details}>{item.phoneNumber}</Text>
          <Text style={styles.details}>{item.products}</Text>
          <Text style={styles.details}>{item.clasification}</Text>
          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={{ ...styles.button, backgroundColor: '#06f' }}
              onPress={() => handleEdit(item)}
            >
              <Text style={styles.buttonText}>Edit</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{ ...styles.button, backgroundColor: '#f34' }}
              onPress={() => {
                setDeleteId(item.id);
                showDeleteDialog();
              }}
            >
              <Text style={styles.buttonText}>Delete</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.settings}>Companies</Text>
      <TouchableOpacity
        style={{
          ...styles.button,
          backgroundColor: '#06f',
          height: 40,
          alignSelf: 'center',
          marginBottom: 10,
          alignItems: 'center',
        }}
        onPress={() => {
          showFilterDialog();
        }}
      >
        <Text style={{ fontSize: 24, color: 'white' }}>Filter</Text>
      </TouchableOpacity>
      {companiesList
        ? companiesList.length != 0
          ? renderCompanies()
          : null
        : null}

      <Portal>
        <Dialog visible={deleteVisible} onDismiss={hideDeleteDialog}>
          <Dialog.Content>
            <Text style={{ fontSize: 24 }}>
              ¿ Are you sure you want to delete this company ?
            </Text>
          </Dialog.Content>
          <Dialog.Actions>
            <TouchableOpacity
              style={{ ...styles.button, backgroundColor: '#f34' }}
              onPress={() => {
                handleDelete();
              }}
            >
              <Text style={{ fontSize: 24, color: 'white' }}>Delete</Text>
            </TouchableOpacity>
          </Dialog.Actions>
        </Dialog>
      </Portal>

      <Portal>
        <Dialog visible={filterVisible} onDismiss={hideFilterDialog}>
          <Dialog.Content>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Name</Text>
              <TextInput
                style={styles.input}
                value={filter.name}
                onChange={(e) => handleFilterChange(e.nativeEvent.text, 'name')}
              />
            </View>
            <View style={styles.inputContainer}>
              <Text style={styles.label}>Clasification</Text>
              <Picker
                selectedValue={filter.clasification}
                onValueChange={(itemValue, itemIndex) =>
                  handleFilterChange(itemValue, 'clasification')
                }
              >
                <Picker.Item
                  label='Software Development'
                  value='Software Development'
                />
                <Picker.Item label='Consulting' value='Consulting' />
                <Picker.Item
                  label='Software Factory'
                  value='Software Factory'
                />
              </Picker>
            </View>
          </Dialog.Content>
          <Dialog.Actions>
            <TouchableOpacity
              style={{ ...styles.button, backgroundColor: '#f34' }}
              onPress={() => {
                handleFilter();
              }}
            >
              <Text style={{ fontSize: 24, color: 'white' }}>Filter</Text>
            </TouchableOpacity>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </ScrollView>
  );
};
export default CompaniesList;

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    height: '100%',
    paddingHorizontal: '5%',
  },
  audioOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  option: {
    paddingHorizontal: '5%',
    paddingVertical: '5%',
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderColor: 'lightgrey',
    justifyContent: 'center',
  },
  optionText: { fontSize: 24 },
  details: { paddingLeft: '5%', fontSize: 20, color: 'grey' },
  subOptionText: {
    color: 'grey',
  },
  settings: { fontSize: 30, paddingVertical: '5%' },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: '5%',
  },
  button: {
    width: '40%',
    backgroundColor: '#06f',
    alignItems: 'center',
    borderRadius: 10,
  },
  buttonText: { color: 'white', fontSize: 24, fontWeight: 'bold' },
  inputContainer: {
    height: 80,
    padding: 5,
  },
  label: {
    fontSize: 20,
  },
  input: {
    fontSize: 20,
    backgroundColor: '#eee',
    borderRadius: 10,
    margin: 5,
    padding: 5,
  },
});
