import React, { useState, useContext } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { Portal, Dialog, Button as Bt } from 'react-native-paper';
import Constants from 'expo-constants';

const Main = ({ navigation }) => {
  const handleCreateGame = () => {};

  const handleAddCompany = () => {
    navigation.push('AddCompany');
  };

  const handleSeeCompanies = () => {
    navigation.push('SeeCompanies');
  };
  const hideNameDialog = () => {
    setNameVisible(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.settings}>Company Manager</Text>
      <TouchableOpacity style={styles.option} onPress={handleSeeCompanies}>
        <Text style={styles.optionText}>See Companies</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.option} onPress={handleAddCompany}>
        <Text style={styles.optionText}>Add Company</Text>
      </TouchableOpacity>
      {/* <Portal>
        <Dialog visible={nameVisible} onDismiss={hideNameDialog}>
          <Dialog.Title>Type a name</Dialog.Title>
          <Dialog.Content>
            <TextInput
              style={{
                fontSize: 30,
                backgroundColor: '#eee',
                borderRadius: 10,
                padding: 5,
              }}
              value={name}
              onChange={(e) => setName(e.nativeEvent.text)}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Bt
              onPress={() => {
                handleCreateGame();
                hideNameDialog();
              }}
            >
              Create
            </Bt>
          </Dialog.Actions>
        </Dialog>
      </Portal> */}
    </View>
  );
};
export default Main;

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    height: '100%',
    paddingHorizontal: '5%',
  },
  audioOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  option: {
    height: '10%',
    paddingHorizontal: '5%',
    borderBottomWidth: 1,
    borderColor: 'lightgrey',
    justifyContent: 'center',
  },
  optionText: { fontSize: 24 },
  subOptionText: {
    color: 'grey',
  },
  settings: { fontSize: 30, paddingVertical: '5%' },
});
