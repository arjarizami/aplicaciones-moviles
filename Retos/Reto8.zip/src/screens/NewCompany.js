import React, { useState, useContext } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import Constants from 'expo-constants';
import CompaniesContext from '../contexts/CompaniesContext.js';
import { Picker } from '@react-native-picker/picker';

const NewCompany = ({ navigation }) => {
  const { createCompany } = useContext(CompaniesContext);

  const [form, setForm] = useState({
    name: '',
    url: '',
    number: '',
    email: '',
    products: '',
    clasification: '',
  });

  const handleFormChange = (value, key) => {
    setForm({ ...form, [key]: value });
    console.log(form);
  };
  const handleSubmit = () => {
    createCompany(form);
    navigation.pop();
    navigation.push('SeeCompanies');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.settings}>Add Company</Text>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>Name</Text>
        <TextInput
          style={styles.input}
          value={form.name}
          onChange={(e) => handleFormChange(e.nativeEvent.text, 'name')}
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>Web Page</Text>
        <TextInput
          style={styles.input}
          value={form.url}
          onChange={(e) => handleFormChange(e.nativeEvent.text, 'url')}
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>Phone Number</Text>
        <TextInput
          style={styles.input}
          value={form.number}
          onChange={(e) => handleFormChange(e.nativeEvent.text, 'number')}
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={form.email}
          onChange={(e) => handleFormChange(e.nativeEvent.text, 'email')}
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>Products</Text>
        <TextInput
          style={styles.input}
          value={form.products}
          onChange={(e) => handleFormChange(e.nativeEvent.text, 'products')}
        />
      </View>
      <View style={styles.inputContainer}>
        <Text style={styles.label}>Clasification</Text>
        <Picker
          selectedValue={form.clasification}
          onValueChange={(itemValue, itemIndex) =>
            handleFormChange(itemValue, 'clasification')
          }
        >
          <Picker.Item
            label='Software Development'
            value='Software Development'
          />
          <Picker.Item label='Consulting' value='Consulting' />
          <Picker.Item label='Software Factory' value='Software Factory' />
        </Picker>
      </View>
      <TouchableOpacity
        style={{
          alignSelf: 'center',
          marginTop: '10%',
          padding: '5%',
          width: '50%',
          backgroundColor: '#07f',
          height: '8%',
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: 10,
        }}
        onPress={handleSubmit}
      >
        <Text
          style={{
            fontSize: 24,
            fontWeight: 'bold',
            color: 'white',
          }}
        >
          Add
        </Text>
      </TouchableOpacity>
    </View>
  );
};
export default NewCompany;

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    height: '100%',
    paddingHorizontal: '5%',
  },
  audioOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  option: {
    height: '10%',
    paddingHorizontal: '5%',
    borderBottomWidth: 1,
    borderColor: 'lightgrey',
    justifyContent: 'center',
  },
  optionText: { fontSize: 24 },
  subOptionText: {
    color: 'grey',
  },
  settings: { fontSize: 30, paddingVertical: '5%' },
  inputContainer: {
    height: '12%',
    padding: 5,
  },
  label: {
    fontSize: 20,
  },
  input: {
    fontSize: 20,
    backgroundColor: '#eee',
    borderRadius: 10,
    margin: 5,
    padding: 5,
  },
});
