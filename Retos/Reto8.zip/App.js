import React from 'react';
import {
  createNavigationContainer,
  NavigationContainer,
} from '@react-navigation/native';
import * as SQLite from 'expo-sqlite';
import db from './src/db/SQLite';

import { createStackNavigator } from '@react-navigation/stack';
import { Provider as PaperProvider } from 'react-native-paper';
import timer from './timer';
import { CompaniesProvider } from './src/contexts/CompaniesContext.js';

import Main from './src/screens/Main';
import CompaniesList from './src/screens/CompaniesList';
import NewCompany from './src/screens/NewCompany';
import EditCompany from './src/screens/EditCompany';

const Stack = createStackNavigator();

/* db.transaction((tx) => {
  tx.executeSql('drop table Empresas', [], (a, b) => {
    console.log('create', b);
  });
}); */

db.transaction((tx) => {
  tx.executeSql(
    'create table if not exists Empresas (id text primary key not null, name text, url text, phoneNumber text, email text, products text, clasification text)',
    [],
    (a, b) => {
      console.log('create', b);
    }
  );
});

/* db.transaction((tx) => {
  tx.executeSql('SELECT * FROM Empresas', [], (a, b) => {
    console.log(b);
  });
}); */

console.ignoredYellowBox = ['Setting a timer'];

export default function App() {
  return (
    <PaperProvider>
      <CompaniesProvider>
        <NavigationContainer>
          <Stack.Navigator
            inittialRoute='Main'
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen name='Main' component={Main} />
            <Stack.Screen name='SeeCompanies' component={CompaniesList} />
            <Stack.Screen name='AddCompany' component={NewCompany} />
            <Stack.Screen name='EditCompany' component={EditCompany} />
          </Stack.Navigator>
        </NavigationContainer>
      </CompaniesProvider>
    </PaperProvider>
  );
}
