import React from 'react';
import {
  createNavigationContainer,
  NavigationContainer,
} from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider as PaperProvider } from 'react-native-paper';

import { GeneralOptionsProvider } from './src/contexts/GeneralOptionsContext';

import Game from './src/screens/Game';
import Settings from './src/screens/Settings';

/* const navigator = createStackNavigator(
  {
    Game: Game,
  },
  {
    initialRouteName: 'Game',
  }
);

export default createAppContainer(navigator); */

const Stack = createStackNavigator();

export default function App() {
  return (
    <PaperProvider>
      <GeneralOptionsProvider>
        <NavigationContainer>
          <Stack.Navigator
            inittialRoute='Game'
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen name='Game' component={Game} />
            <Stack.Screen name='Settings' component={Settings} />
          </Stack.Navigator>
        </NavigationContainer>
      </GeneralOptionsProvider>
    </PaperProvider>
  );
}
