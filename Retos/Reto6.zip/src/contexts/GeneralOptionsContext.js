import React, { useState, useEffect } from 'react';

const GeneralOptionsContext = React.createContext({
  audio: true,
  difficulty: 0,
  victoryMessage: 'You won!',
  reset: 'false',
});

export const GeneralOptionsProvider = ({ children }) => {
  const [audio, setAudio] = useState(true);
  const [difficulty, setDifficulty] = useState('Easy');
  const [victoryMessage, setVictoryMessage] = useState('You won!');
  const [reset, setReset] = useState(false);

  const changeAudio = (value) => {
    setAudio(value);
  };

  const changeDifficulty = (value) => {
    setDifficulty(value);
  };

  const changeVictoryMessage = (value) => {
    setVictoryMessage(value);
  };

  const changeReset = () => {
    setReset(!reset);
  };

  return (
    <GeneralOptionsContext.Provider
      value={{
        audio,
        changeAudio,
        difficulty,
        reset,
        changeDifficulty,
        victoryMessage,
        changeVictoryMessage,
        changeReset,
      }}
    >
      {children}
    </GeneralOptionsContext.Provider>
  );
};

export default GeneralOptionsContext;
