import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import Game from './src/screens/Game';

const navigator = createStackNavigator(
  {
    Game: Game,
  },
  {
    initialRouteName: 'Game',
    defaultNavigationOptions: {
      title: 'TikTakToe',
    },
  }
);

export default createAppContainer(navigator);
