import React, { useEffect, useState } from 'react';
import { Text, StyleSheet, View, Button as RButton } from 'react-native';
import Button from './Button';
import { winner, movesLeft, find_best_move } from '../logic/index';

let initValues = ['', '', '', '', '', '', '', '', ''];

const Game = () => {
  const [player, setPlayer] = useState(0);
  const [values, setValues] = useState(initValues);
  const [finished, setFinished] = useState(false);
  const [win, setWin] = useState(null);

  useEffect(() => {
    const w = winner(values);
    console.log(w);

    if (w) {
      setFinished(true);
      setWin(w);
      return;
    } else if (!movesLeft(values)) {
      console.log(movesLeft(values));
      setFinished(true);
      return;
    }

    if (player === 1 && !finished) {
      const move = find_best_move(values);
      setValues(values.map((el, i) => (i === move ? 'X' : el)));
      setPlayer(0);
    }
  }, values);

  const handleTouch = (index) => {
    if (player === 0 && values[index] === '' && !finished) {
      setValues(values.map((el, i) => (i === index ? 'O' : el)));
      setPlayer(1);
    }
  };

  const onReset = () => {
    setPlayer(0);
    setValues(initValues);
    setFinished(false);
    setWin(null);
  };

  const renderButtons = () => {
    return values.map((value, index) => {
      return (
        <Button
          key={index}
          index={index}
          value={value}
          handleTouch={(index) => handleTouch(index)}
        />
      );
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Your move</Text>
      <View style={styles.gameBoard}>{renderButtons()}</View>
      {finished ? (
        <Text style={styles.text}>
          {win ? (win === 'O' ? 'Player wins' : 'PC wins') : 'Draw'}
        </Text>
      ) : (
        <Text style={styles.text}>Playing</Text>
      )}

      <View style={styles.resetButton}>
        <RButton
          onPress={onReset}
          style={styles.resetButton}
          title='Reset'
          color='red'
        ></RButton>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { alignItems: 'center' },
  text: { fontSize: 30, margin: 20 },
  gameBoard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  resetButton: { width: '40%' },
});

export default Game;
