import React from 'react';
import { StyleSheet, View, Text } from 'react-native';

const Button = ({ index, value, handleTouch }) => {
  return (
    <View
      key={index}
      style={styles.button}
      onTouchEnd={() => handleTouch(index)}
    >
      <Text style={value == 'O' ? styles.textPlayer : styles.textPC}>
        {value !== '' ? value : ''}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  textPlayer: { fontSize: 90, color: 'green' },
  textPC: { fontSize: 90, color: 'red' },
  button: {
    backgroundColor: 'lightgrey',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
    margin: 1,
    minWidth: '25%',
    maxWidth: 120,
    height: 120,
    borderColor: 'black',
    borderWidth: 2,
  },
});

export default Button;
