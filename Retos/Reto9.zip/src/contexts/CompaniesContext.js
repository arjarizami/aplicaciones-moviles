import React, { useState, useEffect } from 'react';
import 'react-native-get-random-values';
import { v4 as uuid } from 'uuid';

const CompaniesContext = React.createContext({
  selectedCompany: {},
  companiesList: [],
});

export const CompaniesProvider = ({ children }) => {
  const [selectedCompany, setSelectedCompany] = useState({});
  const [companiesList, setCompaniesList] = useState([]);

  const selectCompany = (value) => {
    setSelectedCompany(value);
  };

  return (
    <CompaniesContext.Provider value={{}}>{children}</CompaniesContext.Provider>
  );
};

export default CompaniesContext;
