import React, { useState, useContext, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import MapView from 'react-native-maps';
import Constants from 'expo-constants';
import * as Location from 'expo-location';
import axios from 'axios';
import { Marker } from 'react-native-maps';
import { Portal, Dialog, Button as Bt } from 'react-native-paper';
import { MaterialIcons } from '@expo/vector-icons';

const Main = ({ navigation }) => {
  const [location, setLocation] = useState(null);
  const [places, setPlaces] = useState(null);
  const [radius, setRadius] = useState('3');
  const [radiusChanged, setRadiusChanged] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const [dialogVisible, setDialogVisible] = useState(false);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location);
    })();
  }, []);

  useEffect(() => {
    const getPlaces = async () => {
      const places = await axios.get(
        'https://maps.googleapis.com/maps/api/place/nearbysearch/json',
        {
          params: {
            key: 'AIzaSyCteq6LQY2hhYDndiaXevxY1dRHfhikFOM',
            location: `${location.coords.latitude},${location.coords.longitude}`,
            radius: radius * 1000,
          },
        }
      );
      setPlaces(places.data.results);
    };

    if (location) {
      getPlaces();
    }
  }, [location, radiusChanged]);

  const showDialog = () => {
    setDialogVisible(true);
  };

  const hideDialog = () => {
    setDialogVisible(false);
  };

  return (
    <View style={styles.container}>
      {location && (
        <MapView
          style={styles.mapStyle}
          showsPointsOfInterest={false}
          showsUserLocation={true}
          initialRegion={{
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}
          customMapStyle={[
            {
              featureType: 'poi',
              stylers: [
                {
                  visibility: 'off',
                },
              ],
            },
          ]}
        >
          {places &&
            places.map((marker, index) => (
              <Marker
                key={index}
                coordinate={{
                  latitude: marker.geometry.location.lat,
                  longitude: marker.geometry.location.lng,
                }}
                title={marker.name}
                description={marker.description}
                icon={{
                  uri: marker.icon,
                }}
              />
            ))}
        </MapView>
      )}
      <TouchableOpacity style={styles.button} onPress={() => showDialog()}>
        <MaterialIcons name='settings' size={36} color='grey' />
      </TouchableOpacity>
      <Portal>
        <Dialog visible={dialogVisible} onDismiss={hideDialog}>
          <Dialog.Title>Type a radius (Km)</Dialog.Title>
          <Dialog.Content>
            <TextInput
              keyboardType='numeric'
              style={{
                fontSize: 30,
                backgroundColor: '#eee',
                borderRadius: 10,
                padding: 5,
              }}
              value={radius}
              onChange={(e) => setRadius(e.nativeEvent.text)}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Bt
              onPress={() => {
                setRadiusChanged(!radiusChanged);
                hideDialog();
              }}
            >
              Done
            </Bt>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
};
export default Main;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',

    alignItems: 'center',
    justifyContent: 'center',
  },
  mapStyle: {
    width: '100%',
    height: '100%',
  },

  button: {
    position: 'absolute',
    height: 50,
    width: 50,
    backgroundColor: '#eeea',
    bottom: 20,
    right: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
  },
  text: { fontSize: 24 },
});
