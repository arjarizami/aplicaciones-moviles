import { createAppContainer } from 'react-navigation';
import {
  createStackNavigator,
  createBottomTabNavigator,
} from 'react-navigation-stack';
import Game from './src/screens/Game';
import React from 'react';
import { Provider as PaperProvider } from 'react-native-paper';

/* const navigator = createStackNavigator(
  {
    Game: Game,
  },
  {
    initialRouteName: 'Game',
  }
);

export default createAppContainer(navigator); */

export default function App() {
  return (
    <PaperProvider>
      <Game />
    </PaperProvider>
  );
}
