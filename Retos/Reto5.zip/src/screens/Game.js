import React, { useEffect, useState } from 'react';
import { Text, StyleSheet, View, Button as RButton } from 'react-native';
import { Button as Bt, RadioButton, Dialog, Portal } from 'react-native-paper';
import Button from './Button';
import Header from './Header';
import { winner, movesLeft, find_best_move } from '../logic/index';
import { Audio } from 'expo-av';

let initValues = ['', '', '', '', '', '', '', '', ''];
const clickSound = new Audio.Sound();
const winSound = new Audio.Sound();
const loseSound = new Audio.Sound();

const Game = () => {
  const [player, setPlayer] = useState(0);
  const [values, setValues] = useState(initValues);
  const [finished, setFinished] = useState(false);
  const [win, setWin] = useState(null);
  const [visible, setVisible] = React.useState(false);
  const [selectedOption, setSelectedOption] = React.useState('Easy');

  useEffect(() => {
    clickSound.loadAsync(require('../../assets/Click.mp3'));
    winSound.loadAsync(require('../../assets/Win.mp3'));
    loseSound.loadAsync(require('../../assets/Lose.mp3'));
  }, []);

  useEffect(() => {
    const w = winner(values);
    if (w) {
      setFinished(true);
      setWin(w);
      if (w === 'O') {
        winSound.replayAsync();
      } else {
        loseSound.replayAsync();
      }
      return;
    } else if (!movesLeft(values)) {
      setFinished(true);
      return;
    }

    if (player === 1 && !finished) {
      const move = find_best_move(values);
      setValues(values.map((el, i) => (i === move ? 'X' : el)));
      setPlayer(0);
    }
  }, values);

  useEffect(() => {
    onReset();
  }, [selectedOption]);

  const showDialog = () => setVisible(true);
  const hideDialog = () => setVisible(false);

  const handleTouch = (index) => {
    if (player === 0 && values[index] === '' && !finished) {
      clickSound.replayAsync();
      setValues(values.map((el, i) => (i === index ? 'O' : el)));
      setPlayer(1);
    }
  };

  const onReset = () => {
    setPlayer(0);
    setValues(initValues);
    setFinished(false);
    setWin(null);
  };

  const renderButtons = () => {
    return values.map((value, index) => {
      return (
        <Button
          key={index}
          index={index}
          value={value}
          handleTouch={(index) => handleTouch(index)}
        />
      );
    });
  };

  return (
    <View style={styles.container}>
      <Header onReset={onReset} onSettingsSelect={showDialog} />
      <Text style={styles.text}>Your move</Text>
      <View style={styles.gameBoard}>{renderButtons()}</View>
      {finished ? (
        <Text style={styles.text}>
          {win ? (win === 'O' ? 'Player wins' : 'PC wins') : 'Draw'}
        </Text>
      ) : (
        <Text
          style={styles.text}
        >{`Playing. Dificulty: ${selectedOption}`}</Text>
      )}
      <Portal>
        <Dialog visible={visible} onDismiss={hideDialog}>
          <Dialog.Title>Choose Difficulty</Dialog.Title>
          <Dialog.Content>
            <RadioButton.Group
              onValueChange={(value) => setSelectedOption(value)}
              value={selectedOption}
            >
              <RadioButton.Item label='Easy' value={'Easy'} />
              <RadioButton.Item label='Medium' value={'Medium'} />
              <RadioButton.Item label='Hard' value={'Hard'} />
            </RadioButton.Group>
          </Dialog.Content>
          <Dialog.Actions>
            <Bt onPress={hideDialog}>Done</Bt>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { alignItems: 'center', marginTop: 40, minHeight: '100%' },
  text: { fontSize: 30, margin: 20 },
  option: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    maxWidth: 200,
  },
  optionText: {
    fontSize: 5,
  },
  gameBoard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  resetButton: { width: '40%' },
});

export default Game;
