import React from 'react';
import { StyleSheet, View, Text, Image } from 'react-native';
const circle = require('../../assets/circle.png');
const x = require('../../assets/x.png');

const Button = ({ index, value, handleTouch }) => {
  return (
    <View
      key={index}
      style={styles.button}
      onTouchStart={() => handleTouch(index)}
    >
      <Image
        source={value ? (value == 'O' ? circle : x) : null}
        style={styles.image}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  image: {
    maxHeight: '80%',
    maxWidth: '80%',
    alignSelf: 'center',
    margin: '10%',
  },
  button: {
    backgroundColor: 'lightgrey',
    flex: 1,
    flexDirection: 'row',
    margin: 1,
    justifyContent: 'flex-start',
    minWidth: '25%',
    maxWidth: 120,
    height: 120,
    borderColor: 'black',
    borderWidth: 2,
  },
});

export default Button;
