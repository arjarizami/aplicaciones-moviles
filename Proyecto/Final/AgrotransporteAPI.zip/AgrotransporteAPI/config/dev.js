module.exports = {
  googleClientID:
    '191320703531-milebol5l1ee070s3b7g9moktp5sjbuo.apps.googleusercontent.com',
  googleClientSecret: 'rB6UmsknEXXCcHLgqfzv8VS1',
  mongoURI:
    'mongodb+srv://dbAdmin:K55lUMj72OyWckjK@cluster0.y7mvy.mongodb.net/agrodb?retryWrites=true&w=majority',
  stripeSecretKey: 'sk_test_oE38ZUMWX7SQTtuwMu2ZkjHJ00j9hGUqQA',
  stripePublishableKey: 'pk_test_yIeR58jW6RHraV9JaMrwBCg700t4DAzjlV',
};
